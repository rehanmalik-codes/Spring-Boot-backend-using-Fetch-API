
package com.example.spring_fetch_students.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

@RestController
@RequestMapping("/api/students")
public class StudentRestController {

    private final Map<Long, StudentDto> store =
            Collections.synchronizedMap(new LinkedHashMap<>());

    private final AtomicLong idGen = new AtomicLong(1);

    public static class StudentDto {
        public Long id;
        public String rollNumber;
        public String firstName;
        public String lastName;
        public String email;

        public StudentDto() {
        }

        public StudentDto(Long id, String rollNumber,
                          String firstName, String lastName,
                          String email) {
            this.id = id;
            this.rollNumber = rollNumber;
            this.firstName = firstName;
            this.lastName = lastName;
            this.email = email;
        }
    }

    // GET: Fetch all students
    @GetMapping
    public List<StudentDto> list() {
        synchronized (store) {
            return new ArrayList<>(store.values());
        }
    }

    // POST: Add a new student
    @PostMapping
    public ResponseEntity<StudentDto> create(
            @RequestBody StudentDto input) {

        long id = idGen.getAndIncrement();

        StudentDto student = new StudentDto(
                id,
                input.rollNumber,
                input.firstName,
                input.lastName,
                input.email
        );

        store.put(id, student);

        return ResponseEntity.status(201).body(student);
    }

    // DELETE: Delete a student by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {

        StudentDto removed = store.remove(id);

        if (removed == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.noContent().build();
    }
}
