
const baseUrl = "/api/students";

document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("studentForm");
    const listEl = document.getElementById("studentsList");
    const msg = document.getElementById("message");

    // Load and display students
    async function loadStudents() {
        try {
            const res = await fetch(baseUrl);

            if (!res.ok) {
                throw new Error("Failed to load students");
            }

            const students = await res.json();
            renderList(students);
        } catch (error) {
            console.error(error);
            msg.textContent = "Error loading students";
        }
    }

    // Display students on the webpage
    function renderList(students) {
        listEl.innerHTML = "";

        if (students.length === 0) {
            listEl.innerHTML = "<li>No students yet.</li>";
            return;
        }

        students.forEach(student => {
            const li = document.createElement("li");

            li.textContent =
                `${student.rollNumber} — ${student.firstName} ` +
                `${student.lastName || ""} ` +
                `(${student.email || "no email"})`;

            const del = document.createElement("button");
            del.textContent = "Delete";

            del.addEventListener("click", () => {
                deleteStudent(student.id);
            });

            li.appendChild(del);
            listEl.appendChild(li);
        });
    }

    // Add a student using POST
    async function addStudent(data) {
        try {
            const res = await fetch(baseUrl, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            });

            if (res.status === 201) {
                msg.textContent = "Student added successfully!";
                form.reset();
                await loadStudents();
            } else {
                const error = await res.text();
                msg.textContent = "Add failed: " + error;
            }
        } catch (error) {
            console.error(error);
            msg.textContent = "Network error while adding student";
        }
    }

    // Delete a student using DELETE
    async function deleteStudent(id) {
        try {
            const res = await fetch(`${baseUrl}/${id}`, {
                method: "DELETE"
            });

            if (res.status === 204) {
                msg.textContent = "Student deleted successfully!";
                await loadStudents();
            } else {
                msg.textContent = "Delete failed";
            }
        } catch (error) {
            console.error(error);
            msg.textContent = "Network error while deleting student";
        }
    }

    // Handle form submission
    form.addEventListener("submit", event => {
        event.preventDefault();

        const formData = new FormData(form);

        const data = {
            rollNumber: formData.get("rollNumber").trim(),
            firstName: formData.get("firstName").trim(),
            lastName: formData.get("lastName").trim(),
            email: formData.get("email").trim()
        };

        addStudent(data);
    });

    // Load students when the page opens
    loadStudents();
});
