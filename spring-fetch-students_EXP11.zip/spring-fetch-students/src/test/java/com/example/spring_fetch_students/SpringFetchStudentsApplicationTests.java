package com.example.spring_fetch_students;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringFetchStudentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
